import busines from "./assets/images/bussines.png";
import restaurant  from "./assets/images/resturent.png";
import Prtfolio from "./assets/images/portfolio.PNG";
import Landing from "./assets/images/landing.PNG";
import cosmetic from "./assets/images/cosmetic.png";
import industrial from "./assets/images/industrial.png";
import card7 from "./assets/images/card7.PNG";
import Card8 from "./assets/images/card8.PNG";
import card9 from "./assets/images/card9.PNG";

export default function Portfolio() {
return ( <div> <section id="portfolio" className="portfolio section">

    {/* Section Title */}
    <div className="container section-title" data-aos="fade-up">
      <span className="subtitle">Portfolio</span>
      <h2>Portfolio</h2>
      <p>Here are some of the projects I have designed and developed for clients in different industries.</p>
    </div>

    <div className="container" data-aos="fade-up" data-aos-delay="100">

      <div className="isotope-layout" data-default-filter="*" data-layout="masonry" data-sort="original-order">
        <ul className="portfolio-filters isotope-filters" data-aos="fade-up" data-aos-delay="200">
          <li data-filter=".filter-business">Business</li>
          <li data-filter=".filter-restaurant">Restaurant</li>
          <li data-filter=".filter-portfolio">Portfolio</li>
          <li data-filter=".filter-landing">Landing Page</li>
          <li data-filter=".filter-cosmetic">Cosmetic</li>
          <li data-filter=".filter-ecommerce">E-commerce</li>
          <li data-filter=".filter-app">Website Design</li>
          
        </ul>

        <div className="row gy-4 isotope-container" data-aos="fade-up" data-aos-delay="300">

          {/* Project 1 - Business Website */}
          <div className="col-lg-4 col-md-6 portfolio-item isotope-item filter-business">
            <div className="portfolio-card">
              <div className="portfolio-image-container">
                <img src={busines}  alt="Business Website" className="img-fluid" loading="lazy" />
                <div className="portfolio-overlay">
                  <div className="portfolio-info">
                    <span className="project-category">Business Website</span >
                    <h4> Business Site</h4>
                  </div>
                  <div className="portfolio-actions">
                    <a href="https://easycleaningservices.pk/" target="_blank" rel="noopener noreferrer" className="portfolio-link">
                      <i className="bi bi-arrow-right"></i>
                    </a>
                   
                  </div>
                </div>
              </div>
              <div className="portfolio-meta">
                <div className="project-tags">
                  <span className="tag">Corporate</span>
                  <span className="tag">Business</span>
                </div>
                <div className="project-year">2024</div>
              </div>
            </div>
          </div>

          {/* Project 2 - Restaurant Website */}
          <div className="col-lg-4 col-md-6 portfolio-item isotope-item filter-restaurant">
            <div className="portfolio-card">
              <div className="portfolio-image-container">
                <img src={restaurant} alt="Restaurant Website" className="img-fluid" loading="lazy"/>
                <div className="portfolio-overlay">
                  <div className="portfolio-info">
                    <span className="project-category">Restaurant Website</span>
                    <h4>Modern Restaurant Design</h4>
                  </div>
                  <div className="portfolio-actions">
                    <a href=" https://ayeshhdeveloper55.github.io/Lal_Qila_web/" target="_blank" rel="noopener noreferrer" className="portfolio-link">
                      <i className="bi bi-arrow-right"></i>
                    </a>
                  </div>
                </div>
              </div>
              <div className="portfolio-meta">
                <div className="project-tags">
                  <span className="tag">Food</span>
                  <span className="tag">Restaurant</span>
                </div>
                <div className="project-year">2024</div>
              </div>
            </div>
          </div>

          {/* Project 3 - Portfolio Website */}
          <div className="col-lg-4 col-md-6 portfolio-item isotope-item filter-portfolio">
            <div className="portfolio-card">
              <div className="portfolio-image-container">
                <img src={Prtfolio} alt="Portfolio Website" className="img-fluid" loading="lazy"/>
                <div className="portfolio-overlay">
                  <div className="portfolio-info">
                    <span className="project-category">Portfolio Website</span>
                    <h4>Designer Portfolio</h4>
                  </div>
                  <div className="portfolio-actions">
                    <a href="https://ayeshhdeveloper55.github.io/PORTFOLIO_CLIENT/" target="_blank" rel="noopener noreferrer" className="portfolio-link">
                      <i className="bi bi-arrow-right"></i>
                    </a>
                    
                  </div>
                </div>
              </div>
              <div className="portfolio-meta">
                <div className="project-tags">
                  <span className="tag">Portfolio</span>
                  <span className="tag">Design</span>
                </div>
                <div className="project-year">2023</div>
              </div>
            </div>
          </div>

          {/* Project 4 - Landing Page */}
          <div className="col-lg-4 col-md-6 portfolio-item isotope-item filter-landing">
            <div className="portfolio-card">
              <div className="portfolio-image-container">
                <img src={Landing} alt="Landing Page" className="img-fluid" loading="lazy"/>
                <div className="portfolio-overlay">
                  <div className="portfolio-info">
                    <span className="project-category">Landing Page</span>
                    <h4>Marketing Landing Page</h4>
                  </div>
                  <div className="portfolio-actions">
                    <a href="https://ayeshhdeveloper55.github.io/EVEE--SCOOTY--WEBSITE/" target="_blank" rel="noopener noreferrer" className="portfolio-link">
                      <i className="bi bi-arrow-right"></i>
                    </a>
                   
                  </div>
                </div>
              </div>
              <div className="portfolio-meta">
                <div className="project-tags">
                  <span className="tag">Landing</span>
                  <span className="tag">Marketing</span>
                </div>
                <div className="project-year">2023</div>
              </div>
            </div>
          </div>

          {/* Project 5 - Cosmetic Website */}
          <div className="col-lg-4 col-md-6 portfolio-item isotope-item filter-cosmetic">
            <div className="portfolio-card">
              <div className="portfolio-image-container">
                <img src={cosmetic} alt="Cosmetic Website" className="img-fluid" loading="lazy"/>
                <div className="portfolio-overlay">
                  <div className="portfolio-info">
                    <span className="project-category">Cosmetic Website</span>
                    <h4>Beauty & Cosmetic Brand</h4>
                  </div>
                  <div className="portfolio-actions">
                    <a href="https://statuesque-froyo-59ad76.netlify.app/" target="_blank" rel="noopener noreferrer" className="portfolio-link">
                      <i className="bi bi-arrow-right"></i>
                    </a>
                   
                  </div>
                </div>
              </div>
              <div className="portfolio-meta">
                <div className="project-tags">
                  <span className="tag">Cosmetic</span>
                  <span className="tag">Beauty</span>
                </div>
                <div className="project-year">2024</div>
              </div>
            </div>
          </div>

          {/* Project 6 - E-commerce Website */}
          <div className="col-lg-4 col-md-6 portfolio-item isotope-item filter-ecommerce">
            <div className="portfolio-card">
              <div className="portfolio-image-container">
                <img src={industrial} alt="E-commerce Website" className="img-fluid" loading="lazy"/>
                <div className="portfolio-overlay">
                  <div className="portfolio-info">
                    <span className="project-category">Website Design</span>
                    <h4>Industrial website</h4>
                  </div>
                  <div className="portfolio-actions">
                    <a href="https://musical-panda-58cdfb.netlify.app/" target="_blank" rel="noopener noreferrer" className="portfolio-link">
                      <i className="bi bi-arrow-right"></i>
                    </a>
                    
                  </div>
                </div>
              </div>
              <div className="portfolio-meta">
                <div className="project-tags">
                  <span className="tag">Website Design</span>
                  <span className="tag">Industrail</span>
                </div>
                <div className="project-year">2023</div>
              </div>
            </div>
          </div>

          {/* Project 7 - App Design */}
          <div className="col-lg-4 col-md-6 portfolio-item isotope-item filter-app">
            <div className="portfolio-card">
              <div className="portfolio-image-container">
                <img src={card7}alt="App Design" className="img-fluid" loading="lazy"/>
                <div className="portfolio-overlay">
                  <div className="portfolio-info">
                    <span className="project-category">Portfolio Design</span>
                    <h4>JOb Portfolio</h4>
                  </div>
                  <div className="portfolio-actions">
                    <a href="https://ayeshhdeveloper55.github.io/My--personal-portfolio/" target="_blank" rel="noopener noreferrer" className="portfolio-link">
                      <i className="bi bi-arrow-right"></i>
                    </a>
                    
                  </div>
                </div>
              </div>
              <div className="portfolio-meta">
                <div className="project-tags">
                  <span className="tag">website</span>
                  <span className="tag">html and css</span>
                </div>
                <div className="project-year">2024</div>
              </div>
            </div>
          </div>

          {/* Project 8 - Marketing Landing Page */}
          <div className="col-lg-4 col-md-6 portfolio-item isotope-item filter-marketing">
            <div className="portfolio-card">
              <div className="portfolio-image-container">
                <img src={Card8} alt="Marketing Landing" className="img-fluid" loading="lazy"/>
                <div className="portfolio-overlay">
                  <div className="portfolio-info">
                    <span className="project-category"> Deshboard</span>
                    <h4>Design Deshboard Page</h4>
                  </div>
                  <div className="portfolio-actions">
                    <a href="https://example-marketing.com" target="_blank" rel="noopener noreferrer" className="portfolio-link">
                      <i className="bi bi-arrow-right"></i>
                    </a>
                    
                  </div>
                </div>
              </div>
              <div className="portfolio-meta">
                <div className="project-tags">
                  <span className="tag">project</span>
                  <span className="tag">Landing</span>
                </div>
                <div className="project-year">2024</div>
              </div>
            </div>
          </div>

          {/* Project 9 - New Creative Project */}
          <div className="col-lg-4 col-md-6 portfolio-item isotope-item filter-portfolio">
            <div className="portfolio-card">
              <div className="portfolio-image-container">
                <img src={card9} alt="New Project" className="img-fluid" loading="lazy"/>
                <div className="portfolio-overlay">
                  <div className="portfolio-info">
                    <span className="project-category">New Project</span>
                    <h4>Creative Web Design</h4>
                  </div>
                  <div className="portfolio-actions">
                    <a href="https://example-new-project.com" target="_blank" rel="noopener noreferrer" className="portfolio-link">
                      <i className="bi bi-arrow-right"></i>
                    </a>
          
                  </div>
                </div>
              </div>
              <div className="portfolio-meta">
                <div className="project-tags">
                  <span className="tag">Web</span>
                  <span className="tag">Design</span>
                </div>
                <div className="project-year">2025</div>
              </div>
            </div>
          </div>

        </div>
      </div>

      {/* Bottom CTA */}
      <div className="portfolio-bottom" data-aos="fade-up" data-aos-delay="400">
        <div className="row align-items-center">
          <div className="col-lg-8">
            <h3>Like what you see?</h3>
            <p>Let's collaborate to create amazing digital experiences tailored for your business.</p>
          </div>
          <div className="col-lg-4 text-lg-end">
            <a href="#contact" className="btn btn-accent">Let's Work Together</a>
          </div>
        </div>
      </div>

    </div>
  </section>
</div>


)
}
