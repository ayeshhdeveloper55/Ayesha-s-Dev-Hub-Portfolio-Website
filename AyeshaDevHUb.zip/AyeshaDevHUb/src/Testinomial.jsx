

const testimonialsData = [
{
name: "Muhammad Asghar",
role: "Startup Founder",
review: "Ayesha developed a stunning bussines website for my startup. It’s clean, modern, and fully responsive. My clients love it!",
   img: "https://randomuser.me/api/portraits/men/34.jpg",
  link: "https://tubular-sprinkles-4285d4.netlify.app/",
},
{
name: " Ahmed khan",
role: " Industrial Website",
review: "My Bussines Industrail website is amazing! Online orders and reservations have become much easier thanks to her work.",
   img: "https://randomuser.me/api/portraits/men/45.jpg",
avatar: "https://tubular-sprinkles-4285d4.netlify.app/"
},
{
name: "Alishba",
role: "Small Business Owner",
review: "The business website she created is professional and visually appealing. Responsive devices and easy to manage.",
img: "https://randomuser.me/api/portraits/women/68.jpg",

}
];

export default function Testimonials() {
return ( <section id="testimonials" className="testimonials section"> <div className="container"> <div className="section-title" data-aos="fade-up"> <span className="subtitle">Testimonials</span> <h2>What Clients Say</h2> <p>Here’s what my clients have to say about my work and services.</p> </div>


    <div className="row gy-4" data-aos="fade-up" data-aos-delay="100">
      {testimonialsData.map((testimonial, index) => (
        <div key={index} className="col-lg-4 col-md-6">
          <div className="testimonial-item p-4 border rounded shadow-sm">
            <p className="mb-3">"{testimonial.review}"</p>
            <div className="d-flex align-items-center">
              <img 
                src={testimonial.img}
                alt={testimonial.name}
                className="rounded-circle me-3"
                width="50"
                height="50"
              />
              <div>
                <h5 className="mb-0" style={{color: "#ff4d4f"}}>{testimonial.name}</h5>
                <small>{testimonial.role}</small>
              </div>
            </div>
          </div>
        </div>
      ))}
    </div>
  </div>
</section>

);
}
