

export default function Footer() {
return ( <div> <footer id="footer" className="footer">

    <div className="container footer-top">
      <div className="row gy-4">
        {/* About Section */}
        <div className="col-lg-5 col-md-12 footer-about">
          <a href="index.html" className="logo d-flex align-items-center text-decoration-none">
            <span className="sitename">Ayesha Dev Hub</span>
          </a>
          <p>
            I create beautiful, responsive, and user-friendly websites for clients worldwide. Focused on clean design, smooth UX, and fast performance.
          </p>
          <div className="social-links d-flex mt-4">
            <a href="https://twitter.com/" target="_blank" rel="noopener noreferrer"><i className="bi bi-twitter"></i></a>
            <a href="https://facebook.com/" target="_blank" rel="noopener noreferrer"><i className="bi bi-facebook"></i></a>
            <a href="https://instagram.com/" target="_blank" rel="noopener noreferrer"><i className="bi bi-instagram"></i></a>
            <a href="https://linkedin.com/" target="_blank" rel="noopener noreferrer"><i className="bi bi-linkedin"></i></a>
          </div>
        </div>

        {/* Useful Links */}
        <div className="col-lg-2 col-6 footer-links">
          <h4>Useful Links</h4>
          <ul>
            <li><a href="#hero">Home</a></li>
            <li><a href="#about">About us</a></li>
            <li><a href="#services">Services</a></li>
            <li><a href="#portfolio">Portfolio</a></li>
            <li><a href="#contact">Contact</a></li>
          </ul>
        </div>

        {/* Services */}
        <div className="col-lg-2 col-6 footer-links">
          <h4>Our Services</h4>
          <ul>
            <li><a href="#web-design">Web Design</a></li>
            <li><a href="#web-development">Web Development</a></li>
            <li><a href="#ecommerce">Resturent Website</a></li>
            <li><a href="#marketing">Portfolio</a></li>
            <li><a href="#graphic-design">Landing Pages</a></li>
          </ul>
        </div>

        {/* Contact Info */}
        <div className="col-lg-3 col-md-12 footer-contact text-center text-md-start">
          <h4>Contact Me</h4>
          <p>Malir, Karachi</p>
          <p>Pakistan</p>
          <p className="mt-4">
            <strong>Phone:</strong>{" "}
            <a style={{color:"white", textDecoration:"none"}} href="https://wa.me/923141303029" target="_blank" rel="noopener noreferrer">
              +92 314 1303029
            </a>
          </p>
          <p>
            <strong>Email:</strong>{" "}
            <a style={{color:"white", textDecoration:"none"}} href="mailto:ayeshh7766@gmail.com">
              ayeshh7766@gmail.com
            </a>
          </p>
        </div>
      </div>
    </div>

    <div className="container copyright text-center mt-4">
      <p>
        © <span>Copyright</span> <strong className="px-1 sitename">Ayesha Dev Hub</strong> <span>All Rights Reserved</span>
      </p>
      <div className="credits">
        Designed by <a href="https://www.linkedin.com/in/ayesha-asghar-547480332/" target="_blank" rel="noopener noreferrer">Ayesha</a>
      </div>
    </div>

  </footer>
</div>

);
}
