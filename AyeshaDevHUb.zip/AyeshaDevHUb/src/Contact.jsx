import React, { useState } from "react";

export default function Contact() {
  const [formData, setFormData] = useState({ name: "", email: "", subject: "", message: "" });
  const [status, setStatus] = useState(""); // "loading", "error", "success"

  const handleChange = (e) => {
    setFormData({ ...formData, [e.target.name]: e.target.value });
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    setStatus("loading");

    try {
      const response = await fetch("https://formspree.io/f/xpwvdjqd", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(formData)
      });

      if (response.ok) {
        setStatus("success");
        setFormData({ name: "", email: "", subject: "", message: "" });
      } else {
        setStatus("error");
      }
    } catch (error) {
      setStatus("error");
    }
  };

  return (
    <>
      <section id="contact" className="contact section">
        <div className="container section-title" data-aos="fade-up">
          <span className="subtitle">Contact</span>
          <h2>Contact</h2>
          <p>If you have any project ideas or questions, feel free to reach out. I’ll get back to you as soon as possible!</p>
        </div>

        <div className="container">
          <div className="row gy-4">
            <div className="col-lg-4">
              <div className="info-item">
                <div className="icon-wrapper"><i className="bi bi-geo-alt"></i></div>
                <div>
                  <h3  style={{color: "#ff4d4f"}}>Address</h3>
                  <p>Malir, Karachi, Pakistan</p>
                </div>
              </div>

              <div className="info-item">
                <div className="icon-wrapper"><i className="bi bi-telephone"></i></div>
                <div>
                  <h3  style={{color: "#ff4d4f"}}>Call Me</h3>
                  <p><a style={{color: " white", textDecoration: "none"}} href="https://wa.me/923141303029" target="_blank" rel="noopener noreferrer">+92 314 1303029</a></p>
                </div>
              </div>

              <div className="info-item">
                <div className="icon-wrapper"><i className="bi bi-envelope"></i></div>
                <div>
                  <h3 style={{color: "#ff4d4f"}}>Email Me</h3>
                  <p><a style={{color: " white", textDecoration: "none"}} href="mailto:ayeshh7766@gmail.com">ayeshh7766@gmail.com</a></p>
                </div>
              </div>
            </div>

            <div className="col-lg-8">
              <form className="php-email-form" onSubmit={handleSubmit}>
                <div className="row gy-4">
                  <div className="col-md-6">
                    <input
                      type="text"
                      name="name"
                      className="form-control"
                      placeholder="Your Name"
                      value={formData.name}
                      onChange={handleChange}
                      required
                    />
                  </div>

                  <div className="col-md-6">
                    <input
                      type="email"
                      name="email"
                      className="form-control"
                      placeholder="Your Email"
                      value={formData.email}
                      onChange={handleChange}
                      required
                    />
                  </div>

                  <div className="col-md-12">
                    <input
                      type="text"
                      name="subject"
                      className="form-control"
                      placeholder="Subject"
                      value={formData.subject}
                      onChange={handleChange}
                      required
                    />
                  </div>

                  <div className="col-md-12">
                    <textarea
                      name="message"
                      className="form-control"
                      rows="6"
                      placeholder="Message"
                      value={formData.message}
                      onChange={handleChange}
                      required
                    ></textarea>
                  </div>

                  <div className="col-md-12 text-center">
                    {status === "loading" && <div>Loading...</div>}
                    {status === "error" && <div style={{color:"red"}}>Something went wrong. Try again!</div>}
                    {status === "success" && <div style={{color:"green"}}>Your message has been sent. Thank you!</div>}
                    <button type="submit">Send Message</button>
                  </div>
                </div>
              </form>
            </div>
          </div>
        </div>
      </section>
    </>
  );
}
