import banner from "../assets/images/banner.png"; 

export default function Hero() {
  return (
    <section id="hero" className="hero section dark-background">
      <img src={banner} alt="Profile Background" data-aos="fade-in" />

      <div className="container" data-aos="fade-up" data-aos-delay="100">
        <div className="row justify-content-center">
          <div className="col-lg-8 text-center">
            <h2>Hi, I'm Ayesha Asghar</h2>
            <p style={{color : "#ff4d4f"}}>
              I'm a <strong>Frontend Developer</strong>, <strong>Website Designer</strong>, <strong>Freelancer</strong>
            </p>

            <div className="social-links">
              <a href="https://x.com/ayeshh7766"><i className="bi bi-twitter-x"></i></a>
              <a href="https://www.facebook.com/ayesha.asghar.594786/"><i className="bi bi-facebook"></i></a>
              <a href="https://github.com/ayeshhdeveloper55"><i className="bi bi-github"></i></a>
              <a href="https://www.linkedin.com/in/ayesha-asghar-095992371/"><i className="bi bi-linkedin"></i></a>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}

