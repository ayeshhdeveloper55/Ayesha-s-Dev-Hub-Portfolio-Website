

export default function Services() {
return (
   <div> 

  <section id="services" className="services section">

    {/* Section Title */}
    <div className="container section-title" data-aos="fade-up">
      <span className="subtitle">Services</span>
      <h2>Services</h2>
      <p>
        I provide a range of web development services focusing on creating beautiful, responsive, and user-friendly websites tailored to clients’ needs.
      </p>
    </div>

    <div className="container" data-aos="fade-up" data-aos-delay="100">
      <div className="row gy-4">

        {/* Portfolio Websites 01 */}
        <div className="col-lg-3 col-md-6" data-aos="zoom-in" data-aos-delay="100">
          <div className="service-item">
            <div className="icon-wrapper">
              <i className="bi bi-collection"></i>
            </div>
            <h4>Portfolio Websites</h4>
            <p>Professional portfolio websites to showcase your work and personal brand in a clean, modern layout.</p>
            <a href="#service01" style={{color:"pink", textDecoration: "none", fontWeight: "bolder"}} className="explore-link ">Explore</a>
           

          </div>
        </div>

        {/* Landing Pages 02 */}
        <div className="col-lg-3 col-md-6" data-aos="zoom-in" data-aos-delay="200">
          <div className="service-item featured">
            <div className="featured-tag">Featured</div>
            <div className="icon-wrapper">
              <i className="bi bi-layout-text-window-reverse"></i>
            </div>
            <h4>Landing Pages</h4>
            <p>High-converting landing pages for marketing campaigns, products, or services with interactive UI and smooth design.</p>
            <a href="#landing-pages" style={{color:"pink", textDecoration: "none", fontWeight: "bolder"}}  className="explore-link">Explore</a>
          </div>
        </div>

        {/* Restaurant Websites 02 */}
        <div className="col-lg-3 col-md-6" data-aos="zoom-in" data-aos-delay="300">
          <div className="service-item">
            <div className="icon-wrapper">
              <i className="bi bi-shop"></i>
            </div>
            <h4>Restaurant Websites</h4>
            <p>Custom restaurant websites including menus, online orders, and reservation systems with responsive design.</p>
            <a href="#restaurant-websites" style={{color:"pink", textDecoration: "none", fontWeight: "bolder"}}  className="explore-link">Explore</a>
          </div>
        </div>

        {/* Business Websites  04*/}
        <div className="col-lg-3 col-md-6" data-aos="zoom-in" data-aos-delay="400">
          <div className="service-item">
            <div className="icon-wrapper">
              <i className="bi bi-building"></i>
            </div>
            <h4>Business Websites</h4>
            <p>Modern websites for startups and established businesses with responsive layouts, service pages, and contact forms.</p>
            <a href="#business-websites" style={{color:"pink", textDecoration: "none", fontWeight: "bolder"}}  className="explore-link">Explore</a>
          </div>
        </div>
      </div>

      <div className="row mt-5">
        <div className="col-12" data-aos="fade-up" data-aos-delay="200">
          <div className="cta-box">
            <div className="row align-items-center">
              <div className="col-lg-8">
                <h3>Transform Your Vision Into Reality</h3>
                <p>Partner with me to bring your website ideas to life with clean, interactive, and responsive designs tailored to your audience.</p>
              </div>
              <div className="col-lg-4 text-lg-end text-center">
                <a href="#contact" className="cta-btn">Start Your Project</a>
              </div>
            </div>
          </div>
        </div>
      </div>

    </div>
  </section>
</div>


);
}
