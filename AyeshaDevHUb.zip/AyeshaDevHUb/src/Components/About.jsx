import profile from "../assets/profile.jpg"; 
import resume from "../assets/images/Resume.PNG"; 


export default function About() {
return (
   <section id="about" className="about section">

  {/* Section Title */}
  <div className="container section-title" data-aos="fade-up">
    <span className="subtitle">About Me</span>
    <h2>About Me</h2>
    <p>
     I am Ayesha Asghar, a passionate Frontend Developer and Website Designer, currently a student at Saylani Mass IT. I specialize in creating responsive and user-friendly websites and actively work with clients on their web projects using HTML, CSS, Tailwind Css, Bootstrap, React Js, JavaScript, and TypeScript.
    </p>
  </div>

  <div className="container" data-aos="fade-up" data-aos-delay="100">
    <div className="row gy-5">
      {/* Profile Card */}
      <div className="col-lg-4" data-aos="zoom-in" data-aos-delay="150">
        <div className="profile-card">
          <div className="profile-header">
            <div className="profile-avatar">
              {/* Profile Image */}
              <img src={profile} className="img-fluid" alt="Ayesha Asghar"/>
              <div className="status-indicator"></div>
            </div>
            <h3>Ayesha Asghar</h3>
            <span className="role">Frontend Developer</span>
          </div>

          <div className="profile-stats">
            <div className="stat-item">
              <h4>5+</h4>
              <p>Projects</p>
            </div>
            <div className="stat-item">
              <h4>1</h4>
              <p>Website Designing</p>
            </div>
            <div className="stat-item">
              <h4>1</h4>
              <p>Internship</p>
            </div>
          </div>

          <div className="profile-actions">
            {/* Download CV Button */}
           <a href={resume} download className="btn-primary" target="_blank">
  <i className="bi bi-download"></i> Download CV
</a>

            {/* WhatsApp Contact Button */}
            <a
              href="https://wa.me/923141303029"
              target="_blank"
              rel="noopener noreferrer"
              className="btn-secondary"
            >
              <i className="bi bi-whatsapp"></i> Contact
            </a>
          </div>

          <div className="social-connect">
            <a href="https://x.com/ayeshh7766"><i className="bi bi-twitter-x"></i></a>
            <a href="https://www.facebook.com/ayesha.asghar.594786/"><i className="bi bi-facebook"></i></a>
            <a href="https://github.com/ayeshhdeveloper55"><i className="bi bi-github"></i></a>
            <a href="https://www.linkedin.com/in/ayesha-asghar-547480332"><i className="bi bi-linkedin"></i></a>
          </div>
        </div>
      </div>

      {/* About Content */}
      <div className="col-lg-8" data-aos="fade-left" data-aos-delay="200">
        <div className="content-wrapper">
          <div className="bio-section">
            <div className="section-tag">About Me</div>
            <h2>Transforming Ideas into User-Friendly Websites</h2>
            <p>
              I create clean and responsive websites using HTML5, CSS3, Bootstrap5, JavaScript, and TypeScript. I am currently doing an internship with CodeAlpha and actively building projects for clients including e-commerce and portfolio websites.
            </p>
            <p>
              With a strong foundation in web design and development, I aim to turn creative ideas into functional, interactive websites that meet clients' requirements and enhance user experience.
            </p>
          </div>

          <div className="details-grid">
            <div className="detail-item" data-aos="fade-up" data-aos-delay="250">
              <i className="bi bi-briefcase"></i>
              <div className="detail-content">
                <span>Experience</span>
                <strong>1+ Year</strong>
              </div>
            </div>

            <div className="detail-item" data-aos="fade-up" data-aos-delay="300">
              <i className="bi bi-mortarboard"></i>
              <div className="detail-content">
                <span>Education</span>
                <strong>Intermediate - Pre-Medical</strong>
              </div>
            </div>

            <div className="detail-item" data-aos="fade-up" data-aos-delay="350">
              <i className="bi bi-geo-alt"></i>
              <div className="detail-content">
                <span>Based In</span>
                <strong>Karachi, Pakistan</strong>
              </div>
            </div>

            <div className="detail-item" data-aos="fade-up" data-aos-delay="400">
              <i className="bi bi-envelope"></i>
              <div className="detail-content">
                <span>Email</span>
                <strong>ayeshh7766@gmail.com</strong>
              </div>
            </div>

            <div className="detail-item" data-aos="fade-up" data-aos-delay="450">
              <i className="bi bi-phone"></i>
              <div className="detail-content">
                <span>Phone</span>
                <strong>+92 314 1303029</strong>
              </div>
            </div>
          </div>

          <div className="skills-showcase" data-aos="fade-up" data-aos-delay="500">
            <div className="section-tag">Core Skills</div>
            <h3>Technical Proficiency</h3>

            <div className="skills-list skills-animation">
              <div className="skill-item">
                <div className="skill-info">
                  <span className="skill-name">HTML5 &amp; CSS3</span>
                  <span className="skill-percent">95%</span>
                </div>
                <div className="progress">
                  <div style={{ width: "95%", backgroundColor: "#000" }} className="progress-bar" role="progressbar" aria-valuenow="95" aria-valuemin="0" aria-valuemax="100"></div>
                </div>
              </div>

              <div className="skill-item">
                <div className="skill-info">
                  <span className="skill-name">Bootstrap 5</span>
                  <span className="skill-percent">90%</span>
                </div>
                <div  className="progress">
                  <div style={{ width: "90%", backgroundColor: "#000" }}  className="progress-bar" role="progressbar" aria-valuenow="90" aria-valuemin="0" aria-valuemax="100"></div>
                </div>
              </div>

              <div className="skill-item">
                <div className="skill-info">
                  <span className="skill-name">JavaScript &amp; TypeScript</span>
                  <span className="skill-percent">70%</span>
                </div>
                <div className="progress">
                  <div style={{ width: "70%", backgroundColor: "#000" }}  className="progress-bar" role="progressbar" aria-valuenow="70" aria-valuemin="0" aria-valuemax="100"></div>
                </div>
              </div>

              <div className="skill-item">
                <div className="skill-info">
                  <span className="skill-name">React.js</span>
                  <span className="skill-percent">50%</span>
                </div>
                <div className="progress">
                  <div style={{ width: "50%", backgroundColor: "#000" }}  className="progress-bar" role="progressbar" aria-valuenow="85" aria-valuemin="0" aria-valuemax="100"></div>
                </div>
              </div>
              <div className="skill-item">
                <div className="skill-info">
                  <span className="skill-name">Tailwind Css</span>
                  <span className="skill-percent">45%</span>
                </div>
                <div className="progress">
                  <div style={{ width: "45%", backgroundColor: "#000" }}  className="progress-bar" role="progressbar" aria-valuenow="45" aria-valuemin="0" aria-valuemax="100"></div>
                </div>
              </div>

              <div className="skill-item">
                <div className="skill-info">
                  <span className="skill-name">Git &amp; Github</span>
                  <span className="skill-percent">60%</span>
                </div>
                <div className="progress">
                  <div style={{ width: "65%", backgroundColor: "#000" }}  className="progress-bar" role="progressbar" aria-valuenow="80" aria-valuemin="0" aria-valuemax="100"></div>
                </div>
              </div>
              
              <div className="skill-item">
                <div className="skill-info">
                  <span className="skill-name">Next JS  Node JS</span>
                  <span className="skill-percent">30%</span>
                </div>
                <div className="progress">
                  <div style={{ width: "35%", backgroundColor: "#000" }}  className="progress-bar" role="progressbar" aria-valuenow="80" aria-valuemin="0" aria-valuemax="100"></div>
                </div>
              </div>
            </div>
          </div>

        </div>
      </div>

    </div>
  </div>

</section>


);
}