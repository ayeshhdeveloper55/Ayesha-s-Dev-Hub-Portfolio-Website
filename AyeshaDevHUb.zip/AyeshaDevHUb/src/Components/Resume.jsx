export default function Resume() {
return ( <section id="resume" className="resume section">


  {/* Section Title */}
  <div className="container section-title" data-aos="fade-up">
    <span className="subtitle">Resume</span>
    <h2>Resume</h2>
    <p>
      Here’s a snapshot of my professional journey and educational background, showcasing my skills, experience, and certifications as a Frontend Developer and Website Designer.
    </p>
  </div>

  <div className="container" data-aos="fade-up" data-aos-delay="100">
    <div className="row gy-5">

      {/* Experience Section */}
      <div className="col-lg-6">
        <div className="experience-section">
          <div className="section-header" data-aos="fade-right" data-aos-delay="200">
            <div className="header-content">
              <span className="section-badge">Experience</span>
              <h2>Professional Journey</h2>
              <p>Over the past year, I have worked on web development projects including e-commerce, portfolio sites, and responsive website designs using HTML, CSS, Bootstrap, JavaScript, React.js, TypeScript, and Tailwind CSS.</p>
            </div>
          </div>

          <div className="experience-cards">
            <div className="exp-card featured" data-aos="zoom-in" data-aos-delay="300">
              <div className="card-header">
                <div className="company-logo">
                  <i className="bi bi-building"></i>
                </div>
                <div className="period-badge">Current</div>
              </div>
              <div className="card-body">
                <h3>Frontend Developer Intern</h3>
                <p className="company-name">CodeAlpha</p>
                <span className="duration">2025 - Present</span>
                <p className="description">
                  Working on creating responsive, interactive, and client-friendly websites. Tasks include HTML/CSS layout, Bootstrap integration, JavaScript functionality, and React component development.
                </p>
                <div className="skills-tags">
                  <span className="skill-tag">HTML5</span>
                  <span className="skill-tag">CSS3</span>
                  <span className="skill-tag">JavaScript</span>
                  <span className="skill-tag">React.js</span>
                </div>
              </div>
            </div>

            <div className="exp-card" data-aos="zoom-in" data-aos-delay="350">
              <div className="card-header">
                <div className="company-logo">
                  <i className="bi bi-pencil-square"></i>
                </div>
              </div>
              <div className="card-body">
                <h3>Freelance Web Designer</h3>
                <p className="company-name">Independent</p>
                <span className="duration">2024 - Present</span>
                <p className="description">
                  Creating responsive portfolio and e-commerce websites for clients. Implementing clean UI/UX designs with attention to user-friendly layouts.
                </p>
                <div className="skills-tags">
                  <span className="skill-tag">Bootstrap</span>
                  <span className="skill-tag">Tailwind CSS</span>
                  <span className="skill-tag">Responsive Design</span>
                </div>
              </div>
            </div>

            <div className="exp-card" data-aos="zoom-in" data-aos-delay="400">
              <div className="card-header">
                <div className="company-logo">
                  <i className="bi bi-people"></i>
                </div>
              </div>
              <div className="card-body">
                <h3>Teacher</h3>
                <p className="company-name">DSA School, Malir</p>
                <span className="duration">2023</span>
                <p className="description">
                  Taught Drawing, Mathematics, and Cursive Writing to students for one year, receiving recognition for best performance.
                </p>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Education Section */}
      <div className="col-lg-6">
        <div className="education-section">
          <div className="section-header" data-aos="fade-left" data-aos-delay="200">
            <div className="header-content">
              <span className="section-badge">Education</span>
              <h2>Academic Background</h2>
              <p>My academic and certification journey, alongside practical internships, has built a solid foundation for my career in frontend development.</p>
            </div>
          </div>

          <div className="education-timeline" data-aos="fade-left" data-aos-delay="300">
            <div className="timeline-track">

              <div className="timeline-item">
                <div className="timeline-marker">
                  <i className="bi bi-mortarboard-fill"></i>
                </div>
                <div className="timeline-content">
                  <div className="education-meta">
                    <span className="year-range">2023</span>
                    <span className="degree-level">Intermediate</span>
                  </div>
                  <h4>Pre-Medical Group</h4>
                  <p className="institution">Khursheed College, Shah Faisal, Karachi</p>
                </div>
              </div>

              <div className="timeline-item">
                <div className="timeline-marker">
                  <i className="bi bi-book"></i>
                </div>
                <div className="timeline-content">
                  <div className="education-meta">
                    <span className="year-range">2021</span>
                    <span className="degree-level">Matriculation</span>
                  </div>
                  <h4>Science Group</h4>
                  <p className="institution">Jamia Millia School, Malir, Karachi</p>
                </div>
              </div>

              <div className="timeline-item">
                <div className="timeline-marker">
                  <i className="bi bi-patch-check-fill"></i>
                </div>
                <div className="timeline-content">
                  <div className="education-meta">
                    <span className="year-range">2021 - 2025</span>
                    <span className="degree-level">Certifications</span>
                  </div>
                  <h4>Professional Certifications</h4>
                  <div className="certifications-list">
                    <div className="cert-item">
                      <span className="cert-name"> CIT Information Technology</span>
                    </div>
                    <div className="cert-item">
                      <span className="cert-name">HTML5 & CSS3</span>
                    </div>
                    <div className="cert-item">
                      <span className="cert-name">Famhack SMIT</span>
                    </div>
                     <div className="cert-item">
                      <span className="cert-name">Introduction to Programming</span>
                    </div>
                     <div className="cert-item">
                      <span className="cert-name">Full-Stack Developer SMIT</span>
                    </div>
                  </div>
                </div>
              </div>

            </div>
          </div>
        </div>
      </div>

    </div>
  </div>

</section>

)
}
