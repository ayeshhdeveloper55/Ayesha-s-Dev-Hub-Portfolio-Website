import { useState } from "react";
export default function Navbar() {
  const [mobileNav, setMobileNav] = useState(false);

  const handleToggle = () => {
    setMobileNav(!mobileNav);
  };

  return (
    <header
      id="header" data-aos="fade-down"
      className={`header d-flex align-items-center fixed-top ${
        mobileNav ? "mobile-nav-active" : ""
      }`}
    >
      <div className="container-fluid container-xl position-relative d-flex align-items-center">

        {/* Logo */}
        <a href="#hero" className="logo d-flex align-items-center text-decoration-none text-white overflow-y-visible me-auto">
          <h1 className="sitename">Ayesha Dev Hub</h1>
        </a>

        {/* Nav Menu */}
        <nav id="navmenu" className="navmenu">
          <ul>
            <li ><a href="#hero"  onClick={() => setMobileNav(false)}>Home</a></li>
            <li><a href="#about"  onClick={() => setMobileNav(false)}>About</a></li>
            <li><a href="#resume" onClick={() => setMobileNav(false)}>Resume</a></li>
            <li><a href="#services"  onClick={() => setMobileNav(false)}>Services</a></li>
            <li><a href="#portfolio"  onClick={() => setMobileNav(false)}>Portfolio</a></li>
            <li><a href="#testimonials"  onClick={() => setMobileNav(false)}>Testimonial</a></li>
            <li><a href="#contact"  onClick={() => setMobileNav(false)}>Contact</a></li>
          </ul>

          {/* Mobile Toggle Icon */}
          <i
            onClick={handleToggle}
            className={`mobile-nav-toggle d-xl-none bi ${
              mobileNav ? "bi-x" : "bi-list"
            }`}
          ></i>
        </nav>

        {/* Get Started Button */}
        <a className="btn-getstarted text-decoration-none"  href="#about">Started</a>

      </div>
    </header>
  );
}
