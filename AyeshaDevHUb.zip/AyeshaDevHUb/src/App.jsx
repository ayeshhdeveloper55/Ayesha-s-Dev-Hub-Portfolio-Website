



import Contact from "./Contact";
import About from "./Components/About";
import Hero from "./Components/Hero";
import Navbar from "./Components/Navbar";
import Resume from "./Components/Resume";
import Services from "./Components/Services";
import Portfolio from "./Portfolio";
import Testinomial from "./Testinomial";
import Footer from "./Footer";
import "bootstrap-icons/font/bootstrap-icons.css";

export default function App() {
  return (
    <div>
      <Navbar/>
      <Hero/>
      <About/>
      <Resume/>
      <Services/>
      
      <Portfolio/>
      <Testinomial/>
      <Contact/>
      <Footer/>

    </div>
  )
}
